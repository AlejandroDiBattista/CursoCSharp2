// using System;
// using System.IO;
 
// public class Agenda
// {
//     struct tipoPersona
//     {
//         public string nombre;
//         public ushort edad;
//     }
 
//     static int capacidad = 100;
//     static tipoPersona[] gente = new tipoPersona[capacidad];
//     static int cantidad = 0;
//     static bool terminado = false;
 
//     public static void MostrarMenu()
//     {
//         Console.WriteLine("Agenda para curso de c#");
//         Console.WriteLine();
//         Console.WriteLine("1- Añadir una nueva persona");
//         Console.WriteLine("2- Ver nombres de todos");
//         Console.WriteLine("3- Buscar una persona");
//         Console.WriteLine("0- Salir");
//     }
 
//     public static string LeerOpcion() {
//         Console.Write("Escoja una opción: ");
//         string opcion = Console.ReadLine();
//         Console.WriteLine();
//         return opcion;
//     }
 
//     public static void NuevoDato() {
//         if (cantidad < capacidad - 1) {
//             Console.WriteLine("Introduciendo la persona {0}", cantidad + 1);
 
//             Console.Write("Introduzca el nombre: ");
//             gente[cantidad].nombre = Console.ReadLine();
//             cantidad++;
//             Console.WriteLine();
//         }
//     }
 
//     public static void MostrarDatos()  {
//         if (cantidad == 0)
//             Console.WriteLine("No hay datos");
//         else
//             for(int i = 0; i < cantidad; i++)
//                 Console.WriteLine("{0}: {1}",i + 1, gente[i].nombre);
//         Console.WriteLine();
//     }
 
//     public static void BuscarDatos()
//     {
//         Console.Write("¿Dato? ");
//         string buscar = Console.ReadLine();
 
//         bool encontrado = false;
//         for (int i = 0; i < cantidad; i++)
//             if (buscar.ToUpper() == gente[i].nombre.ToUpper())
//             {
//                 encontrado = true;
//                 Console.WriteLine("{0}: Nombre: {1}, i + 1, gente[i].nombre, gente[i]);
//             }
 
//         Console.WriteLine();
//     }
 
//     public static void Main() {
//         do {
//             MostrarMenu();
//             switch (LeerOpcion()) {
//                 case "0": NuevoDato(); break;
//                 case "1": MostrarDatos(); break;
//                 case "2": BuscarDatos(); break;
//                 default:
//                     Console.WriteLine();
//                     Console.WriteLine("Opción incorrecta!");
//                     Console.WriteLine();
//                     break;
//             }
//         } while (!terminado);
//     }
// }
