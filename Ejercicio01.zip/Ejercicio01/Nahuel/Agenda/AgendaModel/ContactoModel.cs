using System;

namespace AgendaModel
{
    public class ContactoModel
    {
        public int Id { get; set; }
        public string Apellido { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }

        public void DisplayDetails()
        {
            Console.WriteLine($"{Id} | {Apellido} | {Nombre} | {Direccion} | {Telefono}");
        }
    }
}