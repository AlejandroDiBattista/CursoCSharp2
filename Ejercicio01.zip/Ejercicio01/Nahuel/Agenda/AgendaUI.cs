using System;

namespace Agenda {
    public class AgendaUI {
        public void Welcome() {
            Console.WriteLine("Bienvenido a Agenda App");
            Console.WriteLine("Seleccione una opcion para continuar");
        }

        public void MenuPrincipal() {
            Console.WriteLine("1. Agregar Contacto");
            Console.WriteLine("2. Seleccionar Contacto");
            Console.WriteLine("3. Mostrar todos los contactos");
        }

        public void MenuContacto() {
            Console.WriteLine("");
            Console.WriteLine("1. Modificar");
            Console.WriteLine("2. Borrar");
        }

        public void ModificarContacto() {
            Console.WriteLine("Seleccione lo que desea modificar");
            Console.WriteLine("1. Apellido");
            Console.WriteLine("2. Nombre");
            Console.WriteLine("3. Direccion");
            Console.WriteLine("4. Telefono");
        }
    }
}