﻿using System;
using AgendaModel;

namespace Agenda {
    class Program2 {
        static void Main2(string[] args) {
            AgendaUI agenda = new AgendaUI();
            AgendaController controller = new AgendaController();
            string userInput = string.Empty;

            Console.Clear();
            agenda.Welcome();
            agenda.MenuPrincipal();

            while (true) {
                userInput = Console.ReadLine();

                switch(userInput) {
                    case "1":
                        Console.WriteLine("Apellido:");
                        var apellido = Console.ReadLine();

                        Console.WriteLine("Nombre:");
                        var nombre = Console.ReadLine();

                        Console.WriteLine("Direccion:");
                        var direccion = Console.ReadLine();

                        Console.WriteLine("Telefono:");
                        var telefono = Console.ReadLine();

                        ContactoModel contacto = new ContactoModel {
                            Apellido = apellido,
                            Nombre = nombre,
                            Direccion = direccion,
                            Telefono = telefono
                        };

                        controller.AgregarContactoModel(contacto);

                        break;

                    case "2":

                        ContactoModel contact;
                        Console.WriteLine("Ingrese nro de contacto:");

                        int id;
                        userInput = Console.ReadLine();

                        if (int.TryParse(userInput, out id)) {
                            contact = controller.ObtenerContactoPorId(id);
                            controller.MostratContacto(id);

                            agenda.MenuContacto();
                            userInput = Console.ReadLine();

                            switch (userInput) {
                                case "1":
                                    agenda.ModificarContacto();
                                    userInput = Console.ReadLine();

                                    switch (userInput) {
                                        case "1":
                                            Console.WriteLine("Apellido:");
                                            apellido = Console.ReadLine();
                                            controller.ModificarContacto(contact, "Apellido", apellido);
                                            Console.Clear();
                                            controller.ListarContactos();
                                            break;

                                        case "2":
                                            Console.WriteLine("Nombre:");
                                            nombre = Console.ReadLine();
                                            controller.ModificarContacto(contact, "Nombre", nombre);
                                            Console.Clear();
                                            controller.ListarContactos();
                                            break;

                                        case "3":
                                            Console.WriteLine("Direccion:");
                                            direccion = Console.ReadLine();
                                            controller.ModificarContacto(contact, "Direccion", direccion);
                                            Console.Clear();
                                            controller.ListarContactos();
                                            break;

                                        case "4":
                                            Console.WriteLine("Telefono:");
                                            telefono = Console.ReadLine();
                                            controller.ModificarContacto(contact, "Telefono", telefono);
                                            Console.Clear();
                                            controller.ListarContactos();
                                            break;
                                    }
                                    break;

                                case "2":
                                    controller.QuitarContacto(contact);

                                    break;
                            }

                        }

                        break;

                    case "3":
                        controller.ListarContactos();
                        break;

                    default:
                        Console.Clear();
                        agenda.MenuPrincipal();
                        break;
                }
            }
        }
    }
}
