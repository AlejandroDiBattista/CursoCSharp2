using System;
using AgendaModel;
using System.Linq;
using System.Collections.Generic;

namespace Agenda {
    public class AgendaController{
        List<ContactoModel> _contactos = new List<ContactoModel>();

        public void AgregarContactoModel(ContactoModel contacto){
            _contactos.Add(contacto);
            contacto.Id = _contactos.IndexOf(contacto);
        }

        public void QuitarContacto(ContactoModel contacto){
            _contactos.Remove(contacto);
            Console.WriteLine("Contacto eliminado correctamente");
        }

        public ContactoModel ObtenerContactoPorId(int Id){
            return _contactos.Where(c => c.Id == Id).FirstOrDefault();
        }

        public void ModificarContacto(ContactoModel contacto, string property, string newValue){
            switch (property){
                case "Apellido":
                    contacto.Apellido = newValue;
                    break;

                case "Nombre":
                    contacto.Nombre = newValue;
                    break;

                case "Direccion":
                    contacto.Direccion = newValue;
                    break;

                case "Telefono":
                    contacto.Telefono = newValue;
                    break;
            }
        }

        public void MostratContacto(int Id){
            ObtenerContactoPorId(Id).DisplayDetails();
        }

        public void ListarContactos(){
            foreach(ContactoModel contacto in _contactos){
                contacto.DisplayDetails();
            }
        }
    }
}