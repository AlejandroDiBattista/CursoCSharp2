using System;

namespace ObjetoPersona
{
    public class Persona
    {
        private int _id;
        private string _nombre;
        private string _apellido;
        private string _telefono;
        private string _email;
        private DateTime _nacimiento;

        public int Id
        {
            set{ _id = value;}
            get { return _id; }
        }

        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }

        public string Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }

        public string Tel
        {
            get { return _telefono; }
            set { _telefono = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _telefono = value; }
        }

        public DateTime Nacimiento
        {
            get { return _nacimiento; }
            set { _nacimiento = value; }
        }

        public Persona()
        { }

        public Persona(int id, string nom, string ape, string tel, string email, DateTime nacimiento)
        {
            _id = id;
            _nombre = nom;
            _apellido = ape;
            _telefono = tel;
            _email = email;
            _nacimiento = nacimiento;
        }
    }
}