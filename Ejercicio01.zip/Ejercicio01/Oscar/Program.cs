﻿using System;
using System.Collections.Generic;
using ObjetoPersona;
using System.IO;


namespace AgendaV2
{
    class Agenda
    {
        static bool terminado = false;

        List<Persona> Amigos = new List<Persona>();

        public string FILE = "MiAgenda.text";

        // public List<Persona> Amigos
        // {
        //     get { return amigo; }
        //     set { _amigo = value; }
        // }

        public void GuardarEnDisco(List<Persona> Amigos)
        {
            StreamWriter fichero = File.CreateText(FILE);
            foreach (Persona amigo in Amigos)
            {
                fichero.WriteLine(amigo.Apellido + "|" + amigo.Nombre + "|" + amigo.Tel + "|" + amigo.Email + "|" + amigo.Nacimiento.ToString("dd/MM/yyyy"));
            }
            fichero.Close();
        }

        public void LeerDeFichero()
        {
            int cont = 0, id = 0, aux1 = 0;
            string lineas = "", nomF = "", apeF = "", telF = "", emailF = "";
            DateTime nac;
            int cantLineas = Amigos.Count;
            if (File.Exists(FILE))
            {
                Console.WriteLine("Leyendo fichero.....");
                StreamReader fichero = File.OpenText(FILE);
                do
                {
                    lineas = fichero.ReadLine();
                    if (lineas == null)
                        break;
                    for (int i = 0; i < lineas.Length; i++)
                    {
                        if (lineas[i] == '|')
                        {
                            cont++;
                            if (cont == 1)
                            {
                                apeF = lineas.Substring(aux1, i);
                                //Console.WriteLine(nomF);
                                aux1 = i + 1;
                            }
                            if (cont == 2)
                            {
                                nomF = lineas.Substring(aux1, i - aux1);
                                //Console.WriteLine(apeF);
                                aux1 = i + 1;
                            }
                            if (cont == 3)
                            {
                                telF = lineas.Substring(aux1, i - aux1);
                                // Console.WriteLine(telF);
                                aux1 = i + 1;
                            }
                            if (cont == 4)
                            {
                                emailF = lineas.Substring(aux1, i - aux1);
                                // Console.WriteLine(emailF);
                                aux1 = i + 1;
                            }

                        }
                    }
                    id++;
                    int dd = int.Parse(lineas.Substring(aux1, 2));
                    int mm = int.Parse(lineas.Substring(aux1 + 3, 2));
                    int yyyy = int.Parse(lineas.Substring(aux1 + 6, 4));
                    aux1 = 0;
                    cont = 0;
                    nac = new DateTime(yyyy, mm, dd);
                    Amigos.Add(new Persona(id, nomF, apeF, telF, emailF, nac));
                } while (lineas != null);
                fichero.Close();
            }
        }

        public Agenda()
        {
            List<Persona> Amigos = new List<Persona>();
        }

        public void MostrarContactos()
        {
            if (Amigos.Count != 0)
            {
                foreach (Persona amigo in Amigos)
                {
                    Console.WriteLine(amigo.Id + "-" + amigo.Apellido + ", " + amigo.Nombre + "," + amigo.Tel + "," + amigo.Email + "," + amigo.Nacimiento.ToString("dd/MM/yyyy"));
                }
            }
            else
            {
                Console.WriteLine("La agenda esta vacia");
            }

            Console.ReadLine();
        }

        public void CargarPersonas()
        {
            int id = 0;
            id++;

            Console.Write("Nombre: ");
            string nom = Console.ReadLine();

            Console.Write("Apellido: ");
            string ape = Console.ReadLine();

            Console.Write("Teléfono: ");
            string tel = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.WriteLine("Ingrese su fecha de nacimiento");
            Console.Write("Dia: ");
            int dia = int.Parse(Console.ReadLine());
            Console.Write("Mes: ");
            int mes = int.Parse(Console.ReadLine());
            Console.Write("Año: ");
            int anio = int.Parse(Console.ReadLine());

            DateTime fech = new DateTime(anio, mes, dia);

            Amigos.Add(new Persona(id, nom, ape, tel, email, fech));

            GuardarEnDisco(Amigos);

        }

        public void ModificarDatos()
        {

            string rta = "s";
            while (rta == "s")
            {

                Console.WriteLine("Datos de la persona a buscar:");
                Console.WriteLine("Nombre:");
                string auxnom = Console.ReadLine();
                Console.WriteLine("Apellido:");
                string auxape = Console.ReadLine();
                //Persona aux=new Persona();
                int flag = 0;

                foreach (Persona a in Amigos)
                {
                    if (a.Nombre == auxnom && a.Apellido == auxape)
                    {
                        flag = 1;
                        Console.WriteLine("Ingrese nuevos datos");
                        CargarPersonas();

                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine("Persona inexistente");
                    Console.Read();
                }
                Console.WriteLine("Modificar otro => s/n?");
                rta = Console.ReadLine();
                while (rta != "s" || rta != "n")
                {
                    Console.WriteLine("Respuesta no valida\n Reingrese");
                    Console.WriteLine("Modificar otro -> s/n?");
                    rta = Console.ReadLine();
                }
            }

        }

        public void EliminarPersonas()
        {
            if (Amigos.Count != 0)
            {
                Console.Write("Nombre de la persona a eliminar: ");
                string nomDel = Console.ReadLine();
                Console.Write("Apellido de la persona a eliminar: ");
                string apeDel = Console.ReadLine();

                foreach (Persona amigo in Amigos)
                {
                    if (amigo.Nombre == nomDel && amigo.Apellido == apeDel)
                    {
                        Console.WriteLine("{0}, {1}", apeDel, nomDel);
                        Console.Write("Realmente desea eliminar esta persona? (1-S / 2-N)");
                        int answer = int.Parse(Console.ReadLine());
                        //Console.WriteLine(answer);
                        while ((answer != 1) && (answer != 2))
                        {
                            Console.WriteLine("Codigo invalodo, debe ingresar (1-S / 2-N)");
                            answer = int.Parse(Console.ReadLine());
                        }
                        if (answer == 1)
                        {
                            Amigos.Remove(amigo);
                            File.Delete(FILE);
                            GuardarEnDisco(Amigos);
                            Console.WriteLine("Persona Eliminada");
                            Console.ReadLine();
                            return;
                        }
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Persona inexistente");
                        Console.ReadLine();
                        return;
                    }
                }
            }
            else
            {
                Console.WriteLine("Agenda Vacia");
                Console.ReadLine();
            }
        }

        public void BuscarPersonas()
        {
            if (Amigos.Count != 0)
            {
                Console.WriteLine("¿A que contacto busca?");
                Console.Write("Nombre de la persona a eliminar: ");
                string nomBusqueda = Console.ReadLine();
                Console.Write("Apellido de la persona a eliminar: ");
                string apeBusqueda = Console.ReadLine();
               
                foreach (Persona amigo in Amigos)
                {
                    if ((amigo.Nombre == nomBusqueda) && (amigo.Apellido == apeBusqueda))
                    {
                        Console.WriteLine("Apellido: {0}, Nombre: {1}, Telefono: {2}, Email: {3}, Fecha de Nacimiento: {4}", amigo.Apellido, amigo.Nombre, amigo.Tel, amigo.Email, amigo.Nacimiento);
                        Console.ReadLine();
                        return;
                    }
                }
                
                    Console.WriteLine("Contacto no existente");
                    Console.ReadLine();
                    return;
                

            }
            else
            {
                Console.WriteLine("Agenda Vacia");
                Console.ReadLine();
                return;
            }
        }

        public void Menu()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("╔══════════════════════════════════════════════╗");
            Console.WriteLine("║                     MENU                     ║");
            Console.WriteLine("╚══════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("1-");
            Console.ResetColor();
            Console.WriteLine("Añadir Contacto");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("2-");
            Console.ResetColor();
            Console.WriteLine("Modificar Datos de Contacto");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("3-");
            Console.ResetColor();
            Console.WriteLine("Mostrar Contactos");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("4-");
            Console.ResetColor();
            Console.WriteLine("Eliminar Contacto");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("5-");
            Console.ResetColor();
            Console.WriteLine("Buscar Contacto");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("0-");
            Console.ResetColor();
            Console.WriteLine("Salir");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.ResetColor();
        }

        public static string LeerOpcion()
        {
            Console.Write("Escoja una opcion: ");
            string opcion = Console.ReadLine();
            Console.WriteLine();
            return opcion;
        }

        static void Main(string[] args)
        {
            Agenda miagenda = new Agenda();
            miagenda.LeerDeFichero();
            do
            {
                miagenda.Menu();
                switch (LeerOpcion())
                {
                    case "1":
                        miagenda.CargarPersonas();
                        break;
                    case "2":
                        //miagenda.ModificarDatos();
                        break;
                    case "3":
                        miagenda.MostrarContactos();
                        break;
                    case "4":
                        miagenda.EliminarPersonas();
                        break;
                    case "5":
                        miagenda.BuscarPersonas();
                        break;
                    case "0":
                        Console.WriteLine("Adios!!");
                        Console.WriteLine();
                        terminado = true;
                        break;
                    default:
                        Console.Beep(200, 35);
                        Console.Write("Opcion incorrecta!");
                        Console.ReadLine();
                        Console.WriteLine();
                        break;
                }
            } while (!terminado);

        }
    }
}
