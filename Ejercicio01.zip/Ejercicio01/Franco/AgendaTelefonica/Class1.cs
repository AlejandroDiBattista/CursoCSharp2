﻿using System;
using System.IO;
namespace AgendaTelefonica
{
    class Class1
    {
#region declarasion de variables
        public static StreamReader LeerArchivo;
        public static StreamWriter EscribirArchivo;
        public string linea = "";
        public string Opcion;
        public string Dui;
        public string Nombre;
        public string Apellido;
        public bool re = false,ree=false;
        int Edad, Bandera, Telefono;
#endregion
        public void Ingresar()
        {

            do
            {
                 //limpia la consola
                Console.Clear();
                 //Abre el archivo Agenda.txt para agregar nuevos datos
                EscribirArchivo = new StreamWriter("Agenda.txt", true);
                 //Pedir que digite los datos para almacenarlos en el archivo Agenda.txt
                #region PedirDatos
                 //Validacion del dni
                do {

                    Console.WriteLine("Digite número de Dni sin guiones:");
                    Dui = Console.ReadLine();
                    int Digitos = Dui.Length;
                    ree = (Digitos <= 8);
                    if (ree == false)
                    {
                        Console.WriteLine("Nesesita 8 Digitos o menos");
                    }


                } while (ree == false);
                //Validacion del nombre para que no queda en blanco
                do{
                    
                    Console.WriteLine("Digite el nombre:");
                    Nombre = Console.ReadLine();
                    if (Nombre == "")
                    {
                       
                    Console.WriteLine("El nombre es obligatorio");
                    }
                } while (Nombre == "");
                //Validacion del apellido para que no queda en blanco
                do
                {
                    Console.WriteLine("Digite el apellido:");
                    Apellido = Console.ReadLine();
                    if (Apellido == "")
                    {

                        Console.WriteLine("El apellido es obligatorio");
                    }

                } while (Apellido == "");
                //validacion de la edad solo numeros
                do
                {
                    try
                    {

                        Console.WriteLine("Digite la edad:");
                        Edad = int.Parse(Console.ReadLine());
                        Bandera = 1;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Dato no valido, vuelva a ingresar la edad del contacto");
                    
                        Bandera = 0;

                    }

                } while (Bandera == 0);


                //Validandando el ingreso del teléfono
                do
                {
                    try
                    {

                        Console.WriteLine("Digite número de Telefono:");
                      Telefono = int.Parse(Console.ReadLine());
                        Bandera = 1;
                    }
                    catch (Exception)
                    {

                        Console.WriteLine("Dato no válido, vuelva a ingresar el teléfono del contacto");
                    
                        Bandera = 0;

                    }

                } while (Bandera == 0);


#endregion

                //Guardando cada uno de los datos ingresados en el archivo de texto
                #region Guaedar
                EscribirArchivo.WriteLine("Dni: " + Dui);
               

                EscribirArchivo.WriteLine("Nombre: " + Nombre);
               

                EscribirArchivo.WriteLine("Apellido: " + Apellido);
              

                EscribirArchivo.WriteLine("Edad: " + Edad);
                           

                EscribirArchivo.WriteLine("Telefono: " + Telefono);
               

#endregion

                #region espacios
                EscribirArchivo.WriteLine("          ");
                Console.WriteLine();
                EscribirArchivo.WriteLine("------------------------------------------------");
                Console.WriteLine();
                EscribirArchivo.WriteLine("          ");
                Console.WriteLine();

 #endregion 
//Cerrar el Archivo Agenda.txt
                Console.WriteLine("DATOS REGISTRADOS");
                EscribirArchivo.Close();

//Preguntar si ingresara otro registro
                #region Ingresar Otro Registro
                do
                {
                    Console.WriteLine("Desea ingresar otro registro? (S/N)");
                    Opcion = Console.ReadLine();
                    re = (Opcion == "S" || Opcion == "s" || Opcion == "N" || Opcion == "n");

                    if (re == false)
                    {

                        Console.WriteLine("Opcion no valida");
                    }
                } while (re == false);
 #endregion 
            } while (Opcion == "S" || Opcion == "s");
//Mostrar los datos registrados

            Dui = "Dni: " + Dui;
            #region Mostrar Datos Ingresados
            if (Opcion == "N" || Opcion == "n") { 
                LeerArchivo = new StreamReader("Agenda.txt", true);
            while (LeerArchivo.EndOfStream == false)
            {
                linea = LeerArchivo.ReadLine();

                if (Dui == linea)
                {
                    Console.WriteLine("DATOS PERSONALES");
                    Console.WriteLine(Dui);

                    for (int i = 1; i <= 5; i++)

                    {

                        Console.WriteLine(LeerArchivo.ReadLine());

                    }


                }


            }
            LeerArchivo.Close();
            }
            #endregion

        }
    }
}
